/* 
 * File:   Abstract.h
 * Author: Andrew Kim
 * Created on June 7, 2014, 2:20 PM
 * Abstract Implementation
 */

#include "Abstract.h"

int Abstract::getStuff() const{
    int wish=10;
    int have;
    
    have=all-wish;
    return have;
}

